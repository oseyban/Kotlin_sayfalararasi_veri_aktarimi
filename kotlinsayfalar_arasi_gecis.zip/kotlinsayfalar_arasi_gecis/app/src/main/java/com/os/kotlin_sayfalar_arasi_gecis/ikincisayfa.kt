package com.os.kotlin_sayfalar_arasi_gecis

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.os.kotlin_sayfalar_arasi_gecis.R.id.textView2

class ikincisayfa : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ikincisayfa)

        //1. sayfadan gelen veriyi al
        val intent = intent
        val alinanveri=intent.getStringExtra("gonderilen")

        val metin=findViewById<TextView>(textView2)
        metin.text=alinanveri.toString()

        Toast.makeText(this,"Merhaba, 2. sayfaya geldin",Toast.LENGTH_LONG).show()
    }




}