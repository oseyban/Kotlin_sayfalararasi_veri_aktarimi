package com.os.kotlin_sayfalar_arasi_gecis


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val gonderButton = findViewById<Button>(R.id.button)
        gonderButton.setOnClickListener {
            degistir()
        }


    }

    //2. sayfaya veri gönder
    fun degistir() {
        val intent=Intent(applicationContext,ikincisayfa::class.java)

        val metin=findViewById<EditText>(R.id.editText)
        val text=metin.text.toString()

        intent.putExtra("gonderilen",text)

        startActivity(intent)
    }
}